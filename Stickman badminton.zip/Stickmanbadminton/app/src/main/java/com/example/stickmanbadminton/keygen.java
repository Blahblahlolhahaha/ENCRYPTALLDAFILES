package com.example.stickmanbadminton;


import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
public class keygen{

    private String lowercase = "qwertyuiopasdfghjklzxcvbnm";
    private String uppercase = lowercase.toUpperCase();
    private String numbers = "1234567890";
    private String special = "~!@#$%^&*()_+{}|:<>?`[];',./";
    private String allofthem = lowercase + uppercase + numbers + special;
    public String password = "";
    private StringBuilder bob = new StringBuilder(password);
    public Key getKey(byte[] s) throws Exception{
        byte[] keymaker = new byte[32];
        for(int i = 0 ; i < keymaker.length-1 ; i++){
            keymaker[i] = s[i];
        }
        return new SecretKeySpec(keymaker,"AES/CBC/PKCS5Padding");
    }
    public Key generator() throws Exception{
        password="";
        int x = (int) Math.round(Math.random()*(allofthem.length()-1));
        for(int i =1; i<=32 ; i++){
            double random = Math.random() * (allofthem.length()-1);
            int position = (int) Math.round(random);
            String congrats = allofthem.substring(position, position+1);
            bob.append(congrats);

        }
        password  = bob.toString();
        Key key = getKey(password.getBytes());
        return key;
    }
    public Key decrypt(String s) throws Exception{
        return getKey(password.getBytes());
    }
    public String returnPassword(){
        return this.password;
    }
}
