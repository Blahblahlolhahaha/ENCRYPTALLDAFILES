package com.example.stickmanbadminton;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class Directory {
    private File file1;
    private File file2;

    Directory(File file1, File file2) {
        this.file1 = file1;
        this.file2 = file2;
    }

    public void checkIsDirectoryAndMove() throws IOException {
        if (this.file1.isDirectory() && this.file2.isDirectory()) {
            File[] src = file1.listFiles();
            if (src != null) {
                for (int i = 0; i < src.length; i++) {
                    File original = src[i];
                    File copy = new File(file2, ("/" + original.getName()));
                    if (original.isFile()) {

                            if (!copy.exists()) {
                                copy.createNewFile();
                            } else {
                                copy.delete();
                                copy.createNewFile();
                            }
                            FileInputStream in = new FileInputStream(original);
                            try{
                                Thread.sleep(500);
                            }catch(InterruptedException e){
                                e.printStackTrace();
                            }

                            FileOutputStream out = new FileOutputStream(copy);
                            try{
                                Thread.sleep(500);
                            }catch(InterruptedException f){
                                f.printStackTrace();
                            }

                            byte[] buf = new byte[1024];
                            int len;
                            while ((len = in.read(buf)) != -1) {
                                ByteArrayOutputStream bsod = new ByteArrayOutputStream();
                                bsod.write(buf, 0, len);
                                out.write(bsod.toByteArray());
                                bsod.close();
                            }

                            in.close();
                            out.close();


                    } else {
                        if (!copy.exists()) {
                            copy.mkdir();
                        } else {
                            copy.delete();
                            copy.mkdir();
                        }
                        Directory rlly = new Directory(original, copy);
                        rlly.checkIsDirectoryAndMove();
                    }
                }
            } else {
                file1.delete();
            }

        }
    }



    public void massDelete(){
        File[] src = this.file1.listFiles();
        for (File i:src
             ) {
            if(i.isFile()){
                i.delete();
            }
            else{
                Directory guts = new Directory(i,i);
                guts.massDelete();
                i.delete();
            }
        }
        this.file1.delete();
    }
    public void zipmyass() throws IOException{
        ZipOutputStream out = new ZipOutputStream(new FileOutputStream(this.file2));
        class ihatemylife{
            ZipOutputStream out;
            File file1;
            ihatemylife(ZipOutputStream out,File file1){
                this.out = out;
                this.file1=file1;
            }
            public void collate() throws IOException{
                if( this.file1.isDirectory()){
                    try {
                        this.out.putNextEntry(new ZipEntry(file1.getPath() + "/"));
                    }catch(ZipException e){
                        e.printStackTrace();
                    }
                    File[] src = this.file1.listFiles();
                    for (File i:
                            src ) {
                        if(i.isDirectory()){
                            ihatemylife suicide = new ihatemylife(this.out,i);
                            suicide.collate();

                        }
                        else{
                            FileInputStream in = new FileInputStream(i);
                            try{
                                this.out.putNextEntry(new ZipEntry(i.getName()));
                                byte[] buf =new byte[1024];
                                int len;
                                while((len = in.read(buf)) != -1){
                                    out.write(buf,0,len);
                                }
                                in.close();
                                out.closeEntry();
                                out.flush();

                            }catch(ZipException e){
                                e.printStackTrace();
                            }


                        }
                    }
                }
                else{
                    FileInputStream in = new FileInputStream(file1);
                    try{
                        this.out.putNextEntry(new ZipEntry(this.file1.getName()));
                        byte[] buf =new byte[1024];
                        int len;
                        while((len = in.read(buf)) != -1){
                            out.write(buf,0,len);
                        }
                        in.close();
                        out.closeEntry();
                        out.flush();

                    }catch(ZipException e){
                        e.printStackTrace();
                    }


                }
            }
        }
        ihatemylife life = new ihatemylife(out,this.file1);
        life.collate();
        out.close();
    }

}
