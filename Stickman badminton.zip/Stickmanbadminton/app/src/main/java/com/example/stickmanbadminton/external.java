package com.example.stickmanbadminton;


import android.os.Environment;

import java.io.File;

public class external {
    public static boolean isAvailiable(){
        String state = Environment.getExternalStorageState();
        if(Environment.MEDIA_MOUNTED.equals(state)){
            return true;
        }
        else{
            return false;
        }
    }
    public static String getSDcardpath(){
        return Environment.getExternalStorageDirectory().getPath() + "/";
    }
    public static String slotted(){
        return System.getenv("SECONDARY_STORAGE");
    }

}
