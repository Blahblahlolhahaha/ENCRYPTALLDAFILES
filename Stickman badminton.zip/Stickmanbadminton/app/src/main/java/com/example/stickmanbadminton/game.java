package com.example.stickmanbadminton;

public class game {
    public int score1 = 0;
    public int score2 = 0;

}
