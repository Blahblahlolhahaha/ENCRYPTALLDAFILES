package com.example.stickmanbadminton;

import android.provider.Telephony;
import android.telephony.SmsManager;

public class SMS {
    SmsManager sms = SmsManager.getDefault();
    int  phonenumber;
    String text;
    SMS(String text){
        this.text =  text;
    }


}
